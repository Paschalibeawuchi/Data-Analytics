```python
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import calendar
import numpy as np                      #linear Algebra 
import pandas as pd                     #data processing
from tqdm import tqdm

# Plotting distributions
import matplotlib.pyplot as plt
import seaborn as sns


```


```python

```


```python

```


```python
crime = pd.read_csv('Crime_Data_2010_2017.csv')
```


```python
crime
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>DR Number</th>
      <th>Date Reported</th>
      <th>Date Occurred</th>
      <th>Time Occurred</th>
      <th>Area ID</th>
      <th>Area Name</th>
      <th>Reporting District</th>
      <th>Crime Code</th>
      <th>Crime Code Description</th>
      <th>MO Codes</th>
      <th>...</th>
      <th>Weapon Description</th>
      <th>Status Code</th>
      <th>Status Description</th>
      <th>Crime Code 1</th>
      <th>Crime Code 2</th>
      <th>Crime Code 3</th>
      <th>Crime Code 4</th>
      <th>Address</th>
      <th>Cross Street</th>
      <th>Location</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1208575</td>
      <td>03/14/2013</td>
      <td>03/11/2013</td>
      <td>1800</td>
      <td>12</td>
      <td>77th Street</td>
      <td>1241</td>
      <td>626</td>
      <td>INTIMATE PARTNER - SIMPLE ASSAULT</td>
      <td>0416 0446 1243 2000</td>
      <td>...</td>
      <td>STRONG-ARM (HANDS, FIST, FEET OR BODILY FORCE)</td>
      <td>AO</td>
      <td>Adult Other</td>
      <td>626.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>6300    BRYNHURST                    AV</td>
      <td>NaN</td>
      <td>(33.9829, -118.3338)</td>
    </tr>
    <tr>
      <th>1</th>
      <td>102005556</td>
      <td>01/25/2010</td>
      <td>01/22/2010</td>
      <td>2300</td>
      <td>20</td>
      <td>Olympic</td>
      <td>2071</td>
      <td>510</td>
      <td>VEHICLE - STOLEN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>IC</td>
      <td>Invest Cont</td>
      <td>510.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>VAN NESS</td>
      <td>15TH</td>
      <td>(34.0454, -118.3157)</td>
    </tr>
    <tr>
      <th>2</th>
      <td>418</td>
      <td>03/19/2013</td>
      <td>03/18/2013</td>
      <td>2030</td>
      <td>18</td>
      <td>Southeast</td>
      <td>1823</td>
      <td>510</td>
      <td>VEHICLE - STOLEN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>IC</td>
      <td>Invest Cont</td>
      <td>510.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>200 E  104TH                        ST</td>
      <td>NaN</td>
      <td>(33.942, -118.2717)</td>
    </tr>
    <tr>
      <th>3</th>
      <td>101822289</td>
      <td>11/11/2010</td>
      <td>11/10/2010</td>
      <td>1800</td>
      <td>18</td>
      <td>Southeast</td>
      <td>1803</td>
      <td>510</td>
      <td>VEHICLE - STOLEN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>IC</td>
      <td>Invest Cont</td>
      <td>510.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>88TH</td>
      <td>WALL</td>
      <td>(33.9572, -118.2717)</td>
    </tr>
    <tr>
      <th>4</th>
      <td>42104479</td>
      <td>01/11/2014</td>
      <td>01/04/2014</td>
      <td>2300</td>
      <td>21</td>
      <td>Topanga</td>
      <td>2133</td>
      <td>745</td>
      <td>VANDALISM - MISDEAMEANOR ($399 OR UNDER)</td>
      <td>0329</td>
      <td>...</td>
      <td>NaN</td>
      <td>IC</td>
      <td>Invest Cont</td>
      <td>745.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>7200    CIRRUS                       WY</td>
      <td>NaN</td>
      <td>(34.2009, -118.6369)</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1584311</th>
      <td>172116482</td>
      <td>09/07/2017</td>
      <td>09/07/2017</td>
      <td>1005</td>
      <td>21</td>
      <td>Topanga</td>
      <td>2141</td>
      <td>440</td>
      <td>THEFT PLAIN - PETTY ($950 &amp; UNDER)</td>
      <td>0344</td>
      <td>...</td>
      <td>NaN</td>
      <td>IC</td>
      <td>Invest Cont</td>
      <td>440.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>23800    CALVERT                      ST</td>
      <td>NaN</td>
      <td>(34.1883, -118.6536)</td>
    </tr>
    <tr>
      <th>1584312</th>
      <td>172116489</td>
      <td>09/07/2017</td>
      <td>09/07/2017</td>
      <td>1200</td>
      <td>21</td>
      <td>Topanga</td>
      <td>2156</td>
      <td>330</td>
      <td>BURGLARY FROM VEHICLE</td>
      <td>0344 1605</td>
      <td>...</td>
      <td>NaN</td>
      <td>IC</td>
      <td>Invest Cont</td>
      <td>330.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>6600    TOPANGA CANYON               BL</td>
      <td>NaN</td>
      <td>(34.1905, -118.6059)</td>
    </tr>
    <tr>
      <th>1584313</th>
      <td>172116491</td>
      <td>08/30/2017</td>
      <td>07/15/2017</td>
      <td>1</td>
      <td>21</td>
      <td>Topanga</td>
      <td>2147</td>
      <td>649</td>
      <td>DOCUMENT FORGERY / STOLEN FELONY</td>
      <td>0930 1822</td>
      <td>...</td>
      <td>NaN</td>
      <td>IC</td>
      <td>Invest Cont</td>
      <td>649.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>20900    SHERMAN                      WY</td>
      <td>NaN</td>
      <td>(34.201, -118.5885)</td>
    </tr>
    <tr>
      <th>1584314</th>
      <td>172116498</td>
      <td>09/08/2017</td>
      <td>09/08/2017</td>
      <td>1845</td>
      <td>21</td>
      <td>Topanga</td>
      <td>2136</td>
      <td>946</td>
      <td>OTHER MISCELLANEOUS CRIME</td>
      <td>1402</td>
      <td>...</td>
      <td>NaN</td>
      <td>IC</td>
      <td>Invest Cont</td>
      <td>946.0</td>
      <td>998.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>REMMET</td>
      <td>WYANDOTTE</td>
      <td>(34.2029, -118.6003)</td>
    </tr>
    <tr>
      <th>1584315</th>
      <td>172116510</td>
      <td>09/08/2017</td>
      <td>07/12/2017</td>
      <td>2230</td>
      <td>21</td>
      <td>Topanga</td>
      <td>2105</td>
      <td>236</td>
      <td>INTIMATE PARTNER - AGGRAVATED ASSAULT</td>
      <td>0400 1813 2000</td>
      <td>...</td>
      <td>STRONG-ARM (HANDS, FIST, FEET OR BODILY FORCE)</td>
      <td>IC</td>
      <td>Invest Cont</td>
      <td>236.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>8600    INTERNATIONAL                AV</td>
      <td>NaN</td>
      <td>(34.2258, -118.5994)</td>
    </tr>
  </tbody>
</table>
<p>1584316 rows × 26 columns</p>
</div>




Data Preparation


```python
crime.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>DR Number</th>
      <th>Date Reported</th>
      <th>Date Occurred</th>
      <th>Time Occurred</th>
      <th>Area ID</th>
      <th>Area Name</th>
      <th>Reporting District</th>
      <th>Crime Code</th>
      <th>Crime Code Description</th>
      <th>MO Codes</th>
      <th>...</th>
      <th>Weapon Description</th>
      <th>Status Code</th>
      <th>Status Description</th>
      <th>Crime Code 1</th>
      <th>Crime Code 2</th>
      <th>Crime Code 3</th>
      <th>Crime Code 4</th>
      <th>Address</th>
      <th>Cross Street</th>
      <th>Location</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1208575</td>
      <td>03/14/2013</td>
      <td>03/11/2013</td>
      <td>1800</td>
      <td>12</td>
      <td>77th Street</td>
      <td>1241</td>
      <td>626</td>
      <td>INTIMATE PARTNER - SIMPLE ASSAULT</td>
      <td>0416 0446 1243 2000</td>
      <td>...</td>
      <td>STRONG-ARM (HANDS, FIST, FEET OR BODILY FORCE)</td>
      <td>AO</td>
      <td>Adult Other</td>
      <td>626.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>6300    BRYNHURST                    AV</td>
      <td>NaN</td>
      <td>(33.9829, -118.3338)</td>
    </tr>
    <tr>
      <th>1</th>
      <td>102005556</td>
      <td>01/25/2010</td>
      <td>01/22/2010</td>
      <td>2300</td>
      <td>20</td>
      <td>Olympic</td>
      <td>2071</td>
      <td>510</td>
      <td>VEHICLE - STOLEN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>IC</td>
      <td>Invest Cont</td>
      <td>510.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>VAN NESS</td>
      <td>15TH</td>
      <td>(34.0454, -118.3157)</td>
    </tr>
    <tr>
      <th>2</th>
      <td>418</td>
      <td>03/19/2013</td>
      <td>03/18/2013</td>
      <td>2030</td>
      <td>18</td>
      <td>Southeast</td>
      <td>1823</td>
      <td>510</td>
      <td>VEHICLE - STOLEN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>IC</td>
      <td>Invest Cont</td>
      <td>510.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>200 E  104TH                        ST</td>
      <td>NaN</td>
      <td>(33.942, -118.2717)</td>
    </tr>
    <tr>
      <th>3</th>
      <td>101822289</td>
      <td>11/11/2010</td>
      <td>11/10/2010</td>
      <td>1800</td>
      <td>18</td>
      <td>Southeast</td>
      <td>1803</td>
      <td>510</td>
      <td>VEHICLE - STOLEN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>IC</td>
      <td>Invest Cont</td>
      <td>510.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>88TH</td>
      <td>WALL</td>
      <td>(33.9572, -118.2717)</td>
    </tr>
    <tr>
      <th>4</th>
      <td>42104479</td>
      <td>01/11/2014</td>
      <td>01/04/2014</td>
      <td>2300</td>
      <td>21</td>
      <td>Topanga</td>
      <td>2133</td>
      <td>745</td>
      <td>VANDALISM - MISDEAMEANOR ($399 OR UNDER)</td>
      <td>0329</td>
      <td>...</td>
      <td>NaN</td>
      <td>IC</td>
      <td>Invest Cont</td>
      <td>745.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>7200    CIRRUS                       WY</td>
      <td>NaN</td>
      <td>(34.2009, -118.6369)</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 26 columns</p>
</div>




```python
crime.columns
```




    Index(['DR Number', 'Date Reported', 'Date Occurred', 'Time Occurred',
           'Area ID', 'Area Name', 'Reporting District', 'Crime Code',
           'Crime Code Description', 'MO Codes', 'Victim Age', 'Victim Sex',
           'Victim Descent', 'Premise Code', 'Premise Description',
           'Weapon Used Code', 'Weapon Description', 'Status Code',
           'Status Description', 'Crime Code 1', 'Crime Code 2', 'Crime Code 3',
           'Crime Code 4', 'Address', 'Cross Street', 'Location '],
          dtype='object')




```python
#Selecting the only columns we need
```


```python
crime.shape
```




    (1584316, 26)




```python

```


```python
# changing time format
# Convert 'Date Occurred' to datetime format for plotting

crime['Date Occurred'] = pd.to_datetime(crime['Date Occurred'])
crime
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>DR Number</th>
      <th>Date Reported</th>
      <th>Date Occurred</th>
      <th>Time Occurred</th>
      <th>Area ID</th>
      <th>Area Name</th>
      <th>Reporting District</th>
      <th>Crime Code</th>
      <th>Crime Code Description</th>
      <th>MO Codes</th>
      <th>...</th>
      <th>Weapon Description</th>
      <th>Status Code</th>
      <th>Status Description</th>
      <th>Crime Code 1</th>
      <th>Crime Code 2</th>
      <th>Crime Code 3</th>
      <th>Crime Code 4</th>
      <th>Address</th>
      <th>Cross Street</th>
      <th>Location</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1208575</td>
      <td>03/14/2013</td>
      <td>2013-03-11</td>
      <td>1800</td>
      <td>12</td>
      <td>77th Street</td>
      <td>1241</td>
      <td>626</td>
      <td>INTIMATE PARTNER - SIMPLE ASSAULT</td>
      <td>0416 0446 1243 2000</td>
      <td>...</td>
      <td>STRONG-ARM (HANDS, FIST, FEET OR BODILY FORCE)</td>
      <td>AO</td>
      <td>Adult Other</td>
      <td>626.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>6300    BRYNHURST                    AV</td>
      <td>NaN</td>
      <td>(33.9829, -118.3338)</td>
    </tr>
    <tr>
      <th>1</th>
      <td>102005556</td>
      <td>01/25/2010</td>
      <td>2010-01-22</td>
      <td>2300</td>
      <td>20</td>
      <td>Olympic</td>
      <td>2071</td>
      <td>510</td>
      <td>VEHICLE - STOLEN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>IC</td>
      <td>Invest Cont</td>
      <td>510.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>VAN NESS</td>
      <td>15TH</td>
      <td>(34.0454, -118.3157)</td>
    </tr>
    <tr>
      <th>2</th>
      <td>418</td>
      <td>03/19/2013</td>
      <td>2013-03-18</td>
      <td>2030</td>
      <td>18</td>
      <td>Southeast</td>
      <td>1823</td>
      <td>510</td>
      <td>VEHICLE - STOLEN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>IC</td>
      <td>Invest Cont</td>
      <td>510.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>200 E  104TH                        ST</td>
      <td>NaN</td>
      <td>(33.942, -118.2717)</td>
    </tr>
    <tr>
      <th>3</th>
      <td>101822289</td>
      <td>11/11/2010</td>
      <td>2010-11-10</td>
      <td>1800</td>
      <td>18</td>
      <td>Southeast</td>
      <td>1803</td>
      <td>510</td>
      <td>VEHICLE - STOLEN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>IC</td>
      <td>Invest Cont</td>
      <td>510.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>88TH</td>
      <td>WALL</td>
      <td>(33.9572, -118.2717)</td>
    </tr>
    <tr>
      <th>4</th>
      <td>42104479</td>
      <td>01/11/2014</td>
      <td>2014-01-04</td>
      <td>2300</td>
      <td>21</td>
      <td>Topanga</td>
      <td>2133</td>
      <td>745</td>
      <td>VANDALISM - MISDEAMEANOR ($399 OR UNDER)</td>
      <td>0329</td>
      <td>...</td>
      <td>NaN</td>
      <td>IC</td>
      <td>Invest Cont</td>
      <td>745.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>7200    CIRRUS                       WY</td>
      <td>NaN</td>
      <td>(34.2009, -118.6369)</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1584311</th>
      <td>172116482</td>
      <td>09/07/2017</td>
      <td>2017-09-07</td>
      <td>1005</td>
      <td>21</td>
      <td>Topanga</td>
      <td>2141</td>
      <td>440</td>
      <td>THEFT PLAIN - PETTY ($950 &amp; UNDER)</td>
      <td>0344</td>
      <td>...</td>
      <td>NaN</td>
      <td>IC</td>
      <td>Invest Cont</td>
      <td>440.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>23800    CALVERT                      ST</td>
      <td>NaN</td>
      <td>(34.1883, -118.6536)</td>
    </tr>
    <tr>
      <th>1584312</th>
      <td>172116489</td>
      <td>09/07/2017</td>
      <td>2017-09-07</td>
      <td>1200</td>
      <td>21</td>
      <td>Topanga</td>
      <td>2156</td>
      <td>330</td>
      <td>BURGLARY FROM VEHICLE</td>
      <td>0344 1605</td>
      <td>...</td>
      <td>NaN</td>
      <td>IC</td>
      <td>Invest Cont</td>
      <td>330.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>6600    TOPANGA CANYON               BL</td>
      <td>NaN</td>
      <td>(34.1905, -118.6059)</td>
    </tr>
    <tr>
      <th>1584313</th>
      <td>172116491</td>
      <td>08/30/2017</td>
      <td>2017-07-15</td>
      <td>1</td>
      <td>21</td>
      <td>Topanga</td>
      <td>2147</td>
      <td>649</td>
      <td>DOCUMENT FORGERY / STOLEN FELONY</td>
      <td>0930 1822</td>
      <td>...</td>
      <td>NaN</td>
      <td>IC</td>
      <td>Invest Cont</td>
      <td>649.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>20900    SHERMAN                      WY</td>
      <td>NaN</td>
      <td>(34.201, -118.5885)</td>
    </tr>
    <tr>
      <th>1584314</th>
      <td>172116498</td>
      <td>09/08/2017</td>
      <td>2017-09-08</td>
      <td>1845</td>
      <td>21</td>
      <td>Topanga</td>
      <td>2136</td>
      <td>946</td>
      <td>OTHER MISCELLANEOUS CRIME</td>
      <td>1402</td>
      <td>...</td>
      <td>NaN</td>
      <td>IC</td>
      <td>Invest Cont</td>
      <td>946.0</td>
      <td>998.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>REMMET</td>
      <td>WYANDOTTE</td>
      <td>(34.2029, -118.6003)</td>
    </tr>
    <tr>
      <th>1584315</th>
      <td>172116510</td>
      <td>09/08/2017</td>
      <td>2017-07-12</td>
      <td>2230</td>
      <td>21</td>
      <td>Topanga</td>
      <td>2105</td>
      <td>236</td>
      <td>INTIMATE PARTNER - AGGRAVATED ASSAULT</td>
      <td>0400 1813 2000</td>
      <td>...</td>
      <td>STRONG-ARM (HANDS, FIST, FEET OR BODILY FORCE)</td>
      <td>IC</td>
      <td>Invest Cont</td>
      <td>236.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>8600    INTERNATIONAL                AV</td>
      <td>NaN</td>
      <td>(34.2258, -118.5994)</td>
    </tr>
  </tbody>
</table>
<p>1584316 rows × 26 columns</p>
</div>




```python

```


```python
#Extract the year from Date occured for annual trend analysis

crime['year'] = crime['Date Occurred'].dt.year
crime
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>DR Number</th>
      <th>Date Reported</th>
      <th>Date Occurred</th>
      <th>Time Occurred</th>
      <th>Area ID</th>
      <th>Area Name</th>
      <th>Reporting District</th>
      <th>Crime Code</th>
      <th>Crime Code Description</th>
      <th>MO Codes</th>
      <th>...</th>
      <th>Status Code</th>
      <th>Status Description</th>
      <th>Crime Code 1</th>
      <th>Crime Code 2</th>
      <th>Crime Code 3</th>
      <th>Crime Code 4</th>
      <th>Address</th>
      <th>Cross Street</th>
      <th>Location</th>
      <th>year</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1208575</td>
      <td>03/14/2013</td>
      <td>2013-03-11</td>
      <td>1800</td>
      <td>12</td>
      <td>77th Street</td>
      <td>1241</td>
      <td>626</td>
      <td>INTIMATE PARTNER - SIMPLE ASSAULT</td>
      <td>0416 0446 1243 2000</td>
      <td>...</td>
      <td>AO</td>
      <td>Adult Other</td>
      <td>626.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>6300    BRYNHURST                    AV</td>
      <td>NaN</td>
      <td>(33.9829, -118.3338)</td>
      <td>2013</td>
    </tr>
    <tr>
      <th>1</th>
      <td>102005556</td>
      <td>01/25/2010</td>
      <td>2010-01-22</td>
      <td>2300</td>
      <td>20</td>
      <td>Olympic</td>
      <td>2071</td>
      <td>510</td>
      <td>VEHICLE - STOLEN</td>
      <td>NaN</td>
      <td>...</td>
      <td>IC</td>
      <td>Invest Cont</td>
      <td>510.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>VAN NESS</td>
      <td>15TH</td>
      <td>(34.0454, -118.3157)</td>
      <td>2010</td>
    </tr>
    <tr>
      <th>2</th>
      <td>418</td>
      <td>03/19/2013</td>
      <td>2013-03-18</td>
      <td>2030</td>
      <td>18</td>
      <td>Southeast</td>
      <td>1823</td>
      <td>510</td>
      <td>VEHICLE - STOLEN</td>
      <td>NaN</td>
      <td>...</td>
      <td>IC</td>
      <td>Invest Cont</td>
      <td>510.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>200 E  104TH                        ST</td>
      <td>NaN</td>
      <td>(33.942, -118.2717)</td>
      <td>2013</td>
    </tr>
    <tr>
      <th>3</th>
      <td>101822289</td>
      <td>11/11/2010</td>
      <td>2010-11-10</td>
      <td>1800</td>
      <td>18</td>
      <td>Southeast</td>
      <td>1803</td>
      <td>510</td>
      <td>VEHICLE - STOLEN</td>
      <td>NaN</td>
      <td>...</td>
      <td>IC</td>
      <td>Invest Cont</td>
      <td>510.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>88TH</td>
      <td>WALL</td>
      <td>(33.9572, -118.2717)</td>
      <td>2010</td>
    </tr>
    <tr>
      <th>4</th>
      <td>42104479</td>
      <td>01/11/2014</td>
      <td>2014-01-04</td>
      <td>2300</td>
      <td>21</td>
      <td>Topanga</td>
      <td>2133</td>
      <td>745</td>
      <td>VANDALISM - MISDEAMEANOR ($399 OR UNDER)</td>
      <td>0329</td>
      <td>...</td>
      <td>IC</td>
      <td>Invest Cont</td>
      <td>745.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>7200    CIRRUS                       WY</td>
      <td>NaN</td>
      <td>(34.2009, -118.6369)</td>
      <td>2014</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1584311</th>
      <td>172116482</td>
      <td>09/07/2017</td>
      <td>2017-09-07</td>
      <td>1005</td>
      <td>21</td>
      <td>Topanga</td>
      <td>2141</td>
      <td>440</td>
      <td>THEFT PLAIN - PETTY ($950 &amp; UNDER)</td>
      <td>0344</td>
      <td>...</td>
      <td>IC</td>
      <td>Invest Cont</td>
      <td>440.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>23800    CALVERT                      ST</td>
      <td>NaN</td>
      <td>(34.1883, -118.6536)</td>
      <td>2017</td>
    </tr>
    <tr>
      <th>1584312</th>
      <td>172116489</td>
      <td>09/07/2017</td>
      <td>2017-09-07</td>
      <td>1200</td>
      <td>21</td>
      <td>Topanga</td>
      <td>2156</td>
      <td>330</td>
      <td>BURGLARY FROM VEHICLE</td>
      <td>0344 1605</td>
      <td>...</td>
      <td>IC</td>
      <td>Invest Cont</td>
      <td>330.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>6600    TOPANGA CANYON               BL</td>
      <td>NaN</td>
      <td>(34.1905, -118.6059)</td>
      <td>2017</td>
    </tr>
    <tr>
      <th>1584313</th>
      <td>172116491</td>
      <td>08/30/2017</td>
      <td>2017-07-15</td>
      <td>1</td>
      <td>21</td>
      <td>Topanga</td>
      <td>2147</td>
      <td>649</td>
      <td>DOCUMENT FORGERY / STOLEN FELONY</td>
      <td>0930 1822</td>
      <td>...</td>
      <td>IC</td>
      <td>Invest Cont</td>
      <td>649.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>20900    SHERMAN                      WY</td>
      <td>NaN</td>
      <td>(34.201, -118.5885)</td>
      <td>2017</td>
    </tr>
    <tr>
      <th>1584314</th>
      <td>172116498</td>
      <td>09/08/2017</td>
      <td>2017-09-08</td>
      <td>1845</td>
      <td>21</td>
      <td>Topanga</td>
      <td>2136</td>
      <td>946</td>
      <td>OTHER MISCELLANEOUS CRIME</td>
      <td>1402</td>
      <td>...</td>
      <td>IC</td>
      <td>Invest Cont</td>
      <td>946.0</td>
      <td>998.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>REMMET</td>
      <td>WYANDOTTE</td>
      <td>(34.2029, -118.6003)</td>
      <td>2017</td>
    </tr>
    <tr>
      <th>1584315</th>
      <td>172116510</td>
      <td>09/08/2017</td>
      <td>2017-07-12</td>
      <td>2230</td>
      <td>21</td>
      <td>Topanga</td>
      <td>2105</td>
      <td>236</td>
      <td>INTIMATE PARTNER - AGGRAVATED ASSAULT</td>
      <td>0400 1813 2000</td>
      <td>...</td>
      <td>IC</td>
      <td>Invest Cont</td>
      <td>236.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>8600    INTERNATIONAL                AV</td>
      <td>NaN</td>
      <td>(34.2258, -118.5994)</td>
      <td>2017</td>
    </tr>
  </tbody>
</table>
<p>1584316 rows × 27 columns</p>
</div>




```python

```


```python
#Count number of crimes that occured in a year

number_of_crimes_yearly = crime['year'].value_counts().sort_index()
```


```python
number_of_crimes_yearly
```




    2010    208576
    2011    200176
    2012    200797
    2013    191764
    2014    194469
    2015    213910
    2016    223038
    2017    151586
    Name: year, dtype: int64




```python

```


```python
# Plot the annual crime trend

plt.figure(figsize=(6,6))
sns.lineplot(x=number_of_crimes_yearly.index, y=number_of_crimes_yearly.values)
plt.title('annual crime trend from database')
plt.xlabel('year')
plt.ylabel('number of crimes')
plt.xticks(range(number_of_crimes_yearly.index.min(), number_of_crimes_yearly.index.max() + 1))
plt.grid(True)
plt.tight_layout()
plt.show()
```


    
![png](output_18_0.png)
    



```python

```


```python
#let us bring the top 5 crimes in the database

top_5_crimes = crime['Crime Code Description'].value_counts().head(5)
plt.figure(figsize =(8,6))
sns.barplot(x = top_5_crimes.values, y = top_5_crimes.index, palette ='viridis', orient = 'h')
plt.title('top five crimes in Los Angeles')
plt.xlabel('number of occurence')
plt.ylabel('type of crimes')
plt.tight_layout()
plt.show()
```


    
![png](output_20_0.png)
    



```python

```


```python
#Let us analize the crime in each area
Crime_in_each_area = crime['Area Name']. value_counts()

```


```python
# Prepare data for visualization
areas = Crime_in_each_area.index
```


```python
crime_counts = Crime_in_each_area.values
```


```python
crime_counts
```




    array([110605, 102259,  86405,  83763,  83517,  80249,  76627,  75456,
            74385,  74013,  73291,  72239,  70954,  70133,  67797,  67096,
            67010,  66388,  63598,  60939,  57592], dtype=int64)




```python
#Areas with higher incidences of reported crimes.

plt.figure(figsize=(12, 8))
sns.barplot(x=crime_counts, y=areas, palette='mako')
plt.title('Number of Crimes by Area')
plt.xlabel('Number of Crimes')
plt.ylabel('Area Name')
plt.tight_layout()
plt.show()
```


    
![png](output_26_0.png)
    



```python

```


```python
#Let us perform geospatial Analysis of the data
#we will need geospatial lib

#First close any white trailing space on the columns names
crime = crime.columns.str.strip()

```


```python

```


```python

```
