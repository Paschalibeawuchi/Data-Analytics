```python

import matplotlib.dates as mdates
import calendar
import numpy as np                      #linear Algebra 
import pandas as pd                     #data processing or manipulation
from tqdm import tqdm

# Plotting distributions
import matplotlib.pyplot as plt    #ploting
import seaborn as sns
```


```python
restaurant = pd.read_csv('restaurant_data.csv', encoding='ascii')
```


```python
restaurant
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Dish Name</th>
      <th>Price</th>
      <th>Dine In</th>
      <th>Parcel</th>
      <th>Total Customers</th>
      <th>Total Sales</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>10/1/2023</td>
      <td>tarri poha</td>
      <td>20</td>
      <td>52</td>
      <td>5</td>
      <td>57</td>
      <td>1140</td>
    </tr>
    <tr>
      <th>1</th>
      <td>10/1/2023</td>
      <td>samosa</td>
      <td>12</td>
      <td>10</td>
      <td>12</td>
      <td>22</td>
      <td>264</td>
    </tr>
    <tr>
      <th>2</th>
      <td>10/1/2023</td>
      <td>samosa</td>
      <td>12</td>
      <td>23</td>
      <td>0</td>
      <td>23</td>
      <td>276</td>
    </tr>
    <tr>
      <th>3</th>
      <td>10/1/2023</td>
      <td>bread pakoda</td>
      <td>20</td>
      <td>29</td>
      <td>24</td>
      <td>53</td>
      <td>1060</td>
    </tr>
    <tr>
      <th>4</th>
      <td>10/1/2023</td>
      <td>bread pakoda</td>
      <td>20</td>
      <td>25</td>
      <td>0</td>
      <td>25</td>
      <td>500</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>644</th>
      <td>11/28/2023</td>
      <td>aloo paratha</td>
      <td>30</td>
      <td>48</td>
      <td>0</td>
      <td>48</td>
      <td>1440</td>
    </tr>
    <tr>
      <th>645</th>
      <td>11/28/2023</td>
      <td>idli</td>
      <td>20</td>
      <td>27</td>
      <td>10</td>
      <td>37</td>
      <td>740</td>
    </tr>
    <tr>
      <th>646</th>
      <td>11/28/2023</td>
      <td>idli</td>
      <td>20</td>
      <td>51</td>
      <td>0</td>
      <td>51</td>
      <td>1020</td>
    </tr>
    <tr>
      <th>647</th>
      <td>11/28/2023</td>
      <td>boiled eggs</td>
      <td>20</td>
      <td>24</td>
      <td>29</td>
      <td>53</td>
      <td>1060</td>
    </tr>
    <tr>
      <th>648</th>
      <td>11/28/2023</td>
      <td>boiled eggs</td>
      <td>20</td>
      <td>26</td>
      <td>10</td>
      <td>36</td>
      <td>720</td>
    </tr>
  </tbody>
</table>
<p>649 rows × 7 columns</p>
</div>




```python
restaurant.shape
```




    (649, 7)




```python
restaurant.tail
```




    <bound method NDFrame.tail of            Date     Dish Name  Price  Dine In  Parcel  Total Customers  \
    0     10/1/2023    tarri poha     20       52       5               57   
    1     10/1/2023        samosa     12       10      12               22   
    2     10/1/2023        samosa     12       23       0               23   
    3     10/1/2023  bread pakoda     20       29      24               53   
    4     10/1/2023  bread pakoda     20       25       0               25   
    ..          ...           ...    ...      ...     ...              ...   
    644  11/28/2023  aloo paratha     30       48       0               48   
    645  11/28/2023          idli     20       27      10               37   
    646  11/28/2023          idli     20       51       0               51   
    647  11/28/2023   boiled eggs     20       24      29               53   
    648  11/28/2023   boiled eggs     20       26      10               36   
    
         Total Sales  
    0           1140  
    1            264  
    2            276  
    3           1060  
    4            500  
    ..           ...  
    644         1440  
    645          740  
    646         1020  
    647         1060  
    648          720  
    
    [649 rows x 7 columns]>




```python
restaurant.head
```




    <bound method NDFrame.head of            Date     Dish Name  Price  Dine In  Parcel  Total Customers  \
    0     10/1/2023    tarri poha     20       52       5               57   
    1     10/1/2023        samosa     12       10      12               22   
    2     10/1/2023        samosa     12       23       0               23   
    3     10/1/2023  bread pakoda     20       29      24               53   
    4     10/1/2023  bread pakoda     20       25       0               25   
    ..          ...           ...    ...      ...     ...              ...   
    644  11/28/2023  aloo paratha     30       48       0               48   
    645  11/28/2023          idli     20       27      10               37   
    646  11/28/2023          idli     20       51       0               51   
    647  11/28/2023   boiled eggs     20       24      29               53   
    648  11/28/2023   boiled eggs     20       26      10               36   
    
         Total Sales  
    0           1140  
    1            264  
    2            276  
    3           1060  
    4            500  
    ..           ...  
    644         1440  
    645          740  
    646         1020  
    647         1060  
    648          720  
    
    [649 rows x 7 columns]>




```python
# Set up the matplotlib figure
sns.set(style='whitegrid')
```


```python
#plot numbers and dimensions
fig, axs = plt.subplots(2, 3, figsize=(18, 10))
```


    
![png](output_7_0.png)
    



```python
# List of columns to plot: Price, Dine In, Parcel, Total Customers, Total Sales
columns_plot = ['Price', 'Dine In', 'Parcel', 'Total Customers', 'Total Sales']
```


```python
# Use tqdm to show progress
for i, column in enumerate(tqdm(columns_plot, desc='Plotting distributions')):
    sns.histplot(restaurant[column], kde=False, ax=axs[i//3, i%3])
    axs[i//3, i%3].set_title('Distribution of ' + column)
```

    Plotting distributions: 100%|██████████| 5/5 [00:00<00:00, 43.29it/s]
    


```python
# Adjust layout
plt.tight_layout()
plt.show()
```


    <Figure size 432x288 with 0 Axes>



```python
fig, axs = plt.subplots(2, 3, figsize=(18, 10))
```


    
![png](output_11_0.png)
    



```python
sns.set(style='whitegrid')
```


```python

```


```python
# To do next

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from tqdm import tqdm
```


```python
file = restaurant
```


```python
file
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Dish Name</th>
      <th>Price</th>
      <th>Dine In</th>
      <th>Parcel</th>
      <th>Total Customers</th>
      <th>Total Sales</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>10/1/2023</td>
      <td>tarri poha</td>
      <td>20</td>
      <td>52</td>
      <td>5</td>
      <td>57</td>
      <td>1140</td>
    </tr>
    <tr>
      <th>1</th>
      <td>10/1/2023</td>
      <td>samosa</td>
      <td>12</td>
      <td>10</td>
      <td>12</td>
      <td>22</td>
      <td>264</td>
    </tr>
    <tr>
      <th>2</th>
      <td>10/1/2023</td>
      <td>samosa</td>
      <td>12</td>
      <td>23</td>
      <td>0</td>
      <td>23</td>
      <td>276</td>
    </tr>
    <tr>
      <th>3</th>
      <td>10/1/2023</td>
      <td>bread pakoda</td>
      <td>20</td>
      <td>29</td>
      <td>24</td>
      <td>53</td>
      <td>1060</td>
    </tr>
    <tr>
      <th>4</th>
      <td>10/1/2023</td>
      <td>bread pakoda</td>
      <td>20</td>
      <td>25</td>
      <td>0</td>
      <td>25</td>
      <td>500</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>644</th>
      <td>11/28/2023</td>
      <td>aloo paratha</td>
      <td>30</td>
      <td>48</td>
      <td>0</td>
      <td>48</td>
      <td>1440</td>
    </tr>
    <tr>
      <th>645</th>
      <td>11/28/2023</td>
      <td>idli</td>
      <td>20</td>
      <td>27</td>
      <td>10</td>
      <td>37</td>
      <td>740</td>
    </tr>
    <tr>
      <th>646</th>
      <td>11/28/2023</td>
      <td>idli</td>
      <td>20</td>
      <td>51</td>
      <td>0</td>
      <td>51</td>
      <td>1020</td>
    </tr>
    <tr>
      <th>647</th>
      <td>11/28/2023</td>
      <td>boiled eggs</td>
      <td>20</td>
      <td>24</td>
      <td>29</td>
      <td>53</td>
      <td>1060</td>
    </tr>
    <tr>
      <th>648</th>
      <td>11/28/2023</td>
      <td>boiled eggs</td>
      <td>20</td>
      <td>26</td>
      <td>10</td>
      <td>36</td>
      <td>720</td>
    </tr>
  </tbody>
</table>
<p>649 rows × 7 columns</p>
</div>




```python
file['Date'] = pd.to_datetime(file['Date'], format='%m/%d/%Y')
```


```python
file
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Dish Name</th>
      <th>Price</th>
      <th>Dine In</th>
      <th>Parcel</th>
      <th>Total Customers</th>
      <th>Total Sales</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2023-10-01</td>
      <td>tarri poha</td>
      <td>20</td>
      <td>52</td>
      <td>5</td>
      <td>57</td>
      <td>1140</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2023-10-01</td>
      <td>samosa</td>
      <td>12</td>
      <td>10</td>
      <td>12</td>
      <td>22</td>
      <td>264</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2023-10-01</td>
      <td>samosa</td>
      <td>12</td>
      <td>23</td>
      <td>0</td>
      <td>23</td>
      <td>276</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2023-10-01</td>
      <td>bread pakoda</td>
      <td>20</td>
      <td>29</td>
      <td>24</td>
      <td>53</td>
      <td>1060</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2023-10-01</td>
      <td>bread pakoda</td>
      <td>20</td>
      <td>25</td>
      <td>0</td>
      <td>25</td>
      <td>500</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>644</th>
      <td>2023-11-28</td>
      <td>aloo paratha</td>
      <td>30</td>
      <td>48</td>
      <td>0</td>
      <td>48</td>
      <td>1440</td>
    </tr>
    <tr>
      <th>645</th>
      <td>2023-11-28</td>
      <td>idli</td>
      <td>20</td>
      <td>27</td>
      <td>10</td>
      <td>37</td>
      <td>740</td>
    </tr>
    <tr>
      <th>646</th>
      <td>2023-11-28</td>
      <td>idli</td>
      <td>20</td>
      <td>51</td>
      <td>0</td>
      <td>51</td>
      <td>1020</td>
    </tr>
    <tr>
      <th>647</th>
      <td>2023-11-28</td>
      <td>boiled eggs</td>
      <td>20</td>
      <td>24</td>
      <td>29</td>
      <td>53</td>
      <td>1060</td>
    </tr>
    <tr>
      <th>648</th>
      <td>2023-11-28</td>
      <td>boiled eggs</td>
      <td>20</td>
      <td>26</td>
      <td>10</td>
      <td>36</td>
      <td>720</td>
    </tr>
  </tbody>
</table>
<p>649 rows × 7 columns</p>
</div>




```python
# Group by 'Date' and 'Dish Name' and sum the 'Total Sales'
daily_sales = file.groupby(['Date', 'Dish Name']).agg({'Total Sales':'sum'}).reset_index()
```


```python
file
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Dish Name</th>
      <th>Price</th>
      <th>Dine In</th>
      <th>Parcel</th>
      <th>Total Customers</th>
      <th>Total Sales</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2023-10-01</td>
      <td>tarri poha</td>
      <td>20</td>
      <td>52</td>
      <td>5</td>
      <td>57</td>
      <td>1140</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2023-10-01</td>
      <td>samosa</td>
      <td>12</td>
      <td>10</td>
      <td>12</td>
      <td>22</td>
      <td>264</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2023-10-01</td>
      <td>samosa</td>
      <td>12</td>
      <td>23</td>
      <td>0</td>
      <td>23</td>
      <td>276</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2023-10-01</td>
      <td>bread pakoda</td>
      <td>20</td>
      <td>29</td>
      <td>24</td>
      <td>53</td>
      <td>1060</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2023-10-01</td>
      <td>bread pakoda</td>
      <td>20</td>
      <td>25</td>
      <td>0</td>
      <td>25</td>
      <td>500</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>644</th>
      <td>2023-11-28</td>
      <td>aloo paratha</td>
      <td>30</td>
      <td>48</td>
      <td>0</td>
      <td>48</td>
      <td>1440</td>
    </tr>
    <tr>
      <th>645</th>
      <td>2023-11-28</td>
      <td>idli</td>
      <td>20</td>
      <td>27</td>
      <td>10</td>
      <td>37</td>
      <td>740</td>
    </tr>
    <tr>
      <th>646</th>
      <td>2023-11-28</td>
      <td>idli</td>
      <td>20</td>
      <td>51</td>
      <td>0</td>
      <td>51</td>
      <td>1020</td>
    </tr>
    <tr>
      <th>647</th>
      <td>2023-11-28</td>
      <td>boiled eggs</td>
      <td>20</td>
      <td>24</td>
      <td>29</td>
      <td>53</td>
      <td>1060</td>
    </tr>
    <tr>
      <th>648</th>
      <td>2023-11-28</td>
      <td>boiled eggs</td>
      <td>20</td>
      <td>26</td>
      <td>10</td>
      <td>36</td>
      <td>720</td>
    </tr>
  </tbody>
</table>
<p>649 rows × 7 columns</p>
</div>




```python
# Sort the data by 'Date'
daily_sales = daily_sales.sort_values(by='Date')
```


```python
file
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Dish Name</th>
      <th>Price</th>
      <th>Dine In</th>
      <th>Parcel</th>
      <th>Total Customers</th>
      <th>Total Sales</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2023-10-01</td>
      <td>tarri poha</td>
      <td>20</td>
      <td>52</td>
      <td>5</td>
      <td>57</td>
      <td>1140</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2023-10-01</td>
      <td>samosa</td>
      <td>12</td>
      <td>10</td>
      <td>12</td>
      <td>22</td>
      <td>264</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2023-10-01</td>
      <td>samosa</td>
      <td>12</td>
      <td>23</td>
      <td>0</td>
      <td>23</td>
      <td>276</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2023-10-01</td>
      <td>bread pakoda</td>
      <td>20</td>
      <td>29</td>
      <td>24</td>
      <td>53</td>
      <td>1060</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2023-10-01</td>
      <td>bread pakoda</td>
      <td>20</td>
      <td>25</td>
      <td>0</td>
      <td>25</td>
      <td>500</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>644</th>
      <td>2023-11-28</td>
      <td>aloo paratha</td>
      <td>30</td>
      <td>48</td>
      <td>0</td>
      <td>48</td>
      <td>1440</td>
    </tr>
    <tr>
      <th>645</th>
      <td>2023-11-28</td>
      <td>idli</td>
      <td>20</td>
      <td>27</td>
      <td>10</td>
      <td>37</td>
      <td>740</td>
    </tr>
    <tr>
      <th>646</th>
      <td>2023-11-28</td>
      <td>idli</td>
      <td>20</td>
      <td>51</td>
      <td>0</td>
      <td>51</td>
      <td>1020</td>
    </tr>
    <tr>
      <th>647</th>
      <td>2023-11-28</td>
      <td>boiled eggs</td>
      <td>20</td>
      <td>24</td>
      <td>29</td>
      <td>53</td>
      <td>1060</td>
    </tr>
    <tr>
      <th>648</th>
      <td>2023-11-28</td>
      <td>boiled eggs</td>
      <td>20</td>
      <td>26</td>
      <td>10</td>
      <td>36</td>
      <td>720</td>
    </tr>
  </tbody>
</table>
<p>649 rows × 7 columns</p>
</div>




```python
# Plot the total sales over time for each dish
plt.figure(figsize=(17, 7))
sns.lineplot(data=daily_sales, x='Date', y='Total Sales', hue='Dish Name')
plt.title('Total Sales recorded Over Time by Dish')

plt.xlabel('Date ')
plt.ylabel('Total Sales')
plt.xticks(rotation=45)
plt.legend(title='Dish Name')
plt.tight_layout()
plt.show()
```


    
![png](output_23_0.png)
    



```python
#This line plotshowing sales trends for different dishes accross the date. 
#Each line represents a dish, allowing you to see how popular each dish is over time and how sales fluctuate
```


```python

```


```python
# Calculate the total revenue and total customers per day
daily_totals = file.groupby('Date').agg({'Total Sales':'sum', 'Total Customers':'sum'}).reset_index()
```


```python
daily_totals
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Total Sales</th>
      <th>Total Customers</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2023-10-01</td>
      <td>7680</td>
      <td>378</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2023-10-02</td>
      <td>8074</td>
      <td>399</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2023-10-03</td>
      <td>6922</td>
      <td>343</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2023-10-04</td>
      <td>8864</td>
      <td>422</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2023-10-05</td>
      <td>7388</td>
      <td>342</td>
    </tr>
    <tr>
      <th>5</th>
      <td>2023-10-06</td>
      <td>9112</td>
      <td>443</td>
    </tr>
    <tr>
      <th>6</th>
      <td>2023-10-07</td>
      <td>8158</td>
      <td>391</td>
    </tr>
    <tr>
      <th>7</th>
      <td>2023-10-08</td>
      <td>8276</td>
      <td>397</td>
    </tr>
    <tr>
      <th>8</th>
      <td>2023-10-09</td>
      <td>8458</td>
      <td>402</td>
    </tr>
    <tr>
      <th>9</th>
      <td>2023-10-10</td>
      <td>8784</td>
      <td>414</td>
    </tr>
    <tr>
      <th>10</th>
      <td>2023-10-11</td>
      <td>9678</td>
      <td>454</td>
    </tr>
    <tr>
      <th>11</th>
      <td>2023-10-12</td>
      <td>7972</td>
      <td>385</td>
    </tr>
    <tr>
      <th>12</th>
      <td>2023-10-13</td>
      <td>8930</td>
      <td>405</td>
    </tr>
    <tr>
      <th>13</th>
      <td>2023-10-14</td>
      <td>8228</td>
      <td>394</td>
    </tr>
    <tr>
      <th>14</th>
      <td>2023-10-15</td>
      <td>7124</td>
      <td>346</td>
    </tr>
    <tr>
      <th>15</th>
      <td>2023-10-16</td>
      <td>6838</td>
      <td>330</td>
    </tr>
    <tr>
      <th>16</th>
      <td>2023-10-17</td>
      <td>8110</td>
      <td>396</td>
    </tr>
    <tr>
      <th>17</th>
      <td>2023-10-18</td>
      <td>8662</td>
      <td>400</td>
    </tr>
    <tr>
      <th>18</th>
      <td>2023-10-19</td>
      <td>9468</td>
      <td>450</td>
    </tr>
    <tr>
      <th>19</th>
      <td>2023-10-20</td>
      <td>7664</td>
      <td>380</td>
    </tr>
    <tr>
      <th>20</th>
      <td>2023-10-21</td>
      <td>9258</td>
      <td>442</td>
    </tr>
    <tr>
      <th>21</th>
      <td>2023-10-22</td>
      <td>8384</td>
      <td>414</td>
    </tr>
    <tr>
      <th>22</th>
      <td>2023-10-23</td>
      <td>9516</td>
      <td>442</td>
    </tr>
    <tr>
      <th>23</th>
      <td>2023-10-24</td>
      <td>9402</td>
      <td>441</td>
    </tr>
    <tr>
      <th>24</th>
      <td>2023-10-25</td>
      <td>8340</td>
      <td>396</td>
    </tr>
    <tr>
      <th>25</th>
      <td>2023-10-26</td>
      <td>8316</td>
      <td>408</td>
    </tr>
    <tr>
      <th>26</th>
      <td>2023-10-27</td>
      <td>9058</td>
      <td>439</td>
    </tr>
    <tr>
      <th>27</th>
      <td>2023-10-28</td>
      <td>7426</td>
      <td>373</td>
    </tr>
    <tr>
      <th>28</th>
      <td>2023-10-29</td>
      <td>8834</td>
      <td>415</td>
    </tr>
    <tr>
      <th>29</th>
      <td>2023-10-30</td>
      <td>9442</td>
      <td>439</td>
    </tr>
    <tr>
      <th>30</th>
      <td>2023-10-31</td>
      <td>7948</td>
      <td>405</td>
    </tr>
    <tr>
      <th>31</th>
      <td>2023-11-01</td>
      <td>8894</td>
      <td>425</td>
    </tr>
    <tr>
      <th>32</th>
      <td>2023-11-02</td>
      <td>6624</td>
      <td>315</td>
    </tr>
    <tr>
      <th>33</th>
      <td>2023-11-03</td>
      <td>8910</td>
      <td>425</td>
    </tr>
    <tr>
      <th>34</th>
      <td>2023-11-04</td>
      <td>8626</td>
      <td>396</td>
    </tr>
    <tr>
      <th>35</th>
      <td>2023-11-05</td>
      <td>7464</td>
      <td>370</td>
    </tr>
    <tr>
      <th>36</th>
      <td>2023-11-06</td>
      <td>7166</td>
      <td>373</td>
    </tr>
    <tr>
      <th>37</th>
      <td>2023-11-07</td>
      <td>8692</td>
      <td>408</td>
    </tr>
    <tr>
      <th>38</th>
      <td>2023-11-08</td>
      <td>8404</td>
      <td>401</td>
    </tr>
    <tr>
      <th>39</th>
      <td>2023-11-09</td>
      <td>7654</td>
      <td>370</td>
    </tr>
    <tr>
      <th>40</th>
      <td>2023-11-10</td>
      <td>9300</td>
      <td>433</td>
    </tr>
    <tr>
      <th>41</th>
      <td>2023-11-11</td>
      <td>8650</td>
      <td>412</td>
    </tr>
    <tr>
      <th>42</th>
      <td>2023-11-12</td>
      <td>8232</td>
      <td>388</td>
    </tr>
    <tr>
      <th>43</th>
      <td>2023-11-13</td>
      <td>7858</td>
      <td>398</td>
    </tr>
    <tr>
      <th>44</th>
      <td>2023-11-14</td>
      <td>7936</td>
      <td>379</td>
    </tr>
    <tr>
      <th>45</th>
      <td>2023-11-15</td>
      <td>7306</td>
      <td>349</td>
    </tr>
    <tr>
      <th>46</th>
      <td>2023-11-16</td>
      <td>9670</td>
      <td>468</td>
    </tr>
    <tr>
      <th>47</th>
      <td>2023-11-17</td>
      <td>7702</td>
      <td>371</td>
    </tr>
    <tr>
      <th>48</th>
      <td>2023-11-18</td>
      <td>8742</td>
      <td>423</td>
    </tr>
    <tr>
      <th>49</th>
      <td>2023-11-19</td>
      <td>7114</td>
      <td>351</td>
    </tr>
    <tr>
      <th>50</th>
      <td>2023-11-20</td>
      <td>7746</td>
      <td>351</td>
    </tr>
    <tr>
      <th>51</th>
      <td>2023-11-21</td>
      <td>9342</td>
      <td>449</td>
    </tr>
    <tr>
      <th>52</th>
      <td>2023-11-22</td>
      <td>8276</td>
      <td>380</td>
    </tr>
    <tr>
      <th>53</th>
      <td>2023-11-23</td>
      <td>8422</td>
      <td>403</td>
    </tr>
    <tr>
      <th>54</th>
      <td>2023-11-24</td>
      <td>8572</td>
      <td>408</td>
    </tr>
    <tr>
      <th>55</th>
      <td>2023-11-25</td>
      <td>6754</td>
      <td>316</td>
    </tr>
    <tr>
      <th>56</th>
      <td>2023-11-26</td>
      <td>10436</td>
      <td>489</td>
    </tr>
    <tr>
      <th>57</th>
      <td>2023-11-27</td>
      <td>8172</td>
      <td>386</td>
    </tr>
    <tr>
      <th>58</th>
      <td>2023-11-28</td>
      <td>8832</td>
      <td>424</td>
    </tr>
  </tbody>
</table>
</div>




```python

# Calculate the average price per dish per day

file['Price per Dish'] = file['Total Sales'] / (file['Dine In'] + file['Parcel'])

daily_average_price = file.groupby('Date')['Price per Dish'].mean().reset_index()

```


```python
daily_average_price per dish
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Price per Dish</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2023-10-01</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2023-10-02</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2023-10-03</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2023-10-04</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2023-10-05</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>5</th>
      <td>2023-10-06</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>6</th>
      <td>2023-10-07</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>7</th>
      <td>2023-10-08</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>8</th>
      <td>2023-10-09</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>9</th>
      <td>2023-10-10</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>10</th>
      <td>2023-10-11</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>11</th>
      <td>2023-10-12</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>12</th>
      <td>2023-10-13</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>13</th>
      <td>2023-10-14</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>14</th>
      <td>2023-10-15</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>15</th>
      <td>2023-10-16</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>16</th>
      <td>2023-10-17</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>17</th>
      <td>2023-10-18</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>18</th>
      <td>2023-10-19</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>19</th>
      <td>2023-10-20</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>20</th>
      <td>2023-10-21</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>21</th>
      <td>2023-10-22</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>22</th>
      <td>2023-10-23</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>23</th>
      <td>2023-10-24</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>24</th>
      <td>2023-10-25</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>25</th>
      <td>2023-10-26</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>26</th>
      <td>2023-10-27</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>27</th>
      <td>2023-10-28</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>28</th>
      <td>2023-10-29</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>29</th>
      <td>2023-10-30</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>30</th>
      <td>2023-10-31</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>31</th>
      <td>2023-11-01</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>32</th>
      <td>2023-11-02</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>33</th>
      <td>2023-11-03</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>34</th>
      <td>2023-11-04</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>35</th>
      <td>2023-11-05</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>36</th>
      <td>2023-11-06</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>37</th>
      <td>2023-11-07</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>38</th>
      <td>2023-11-08</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>39</th>
      <td>2023-11-09</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>40</th>
      <td>2023-11-10</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>41</th>
      <td>2023-11-11</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>42</th>
      <td>2023-11-12</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>43</th>
      <td>2023-11-13</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>44</th>
      <td>2023-11-14</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>45</th>
      <td>2023-11-15</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>46</th>
      <td>2023-11-16</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>47</th>
      <td>2023-11-17</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>48</th>
      <td>2023-11-18</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>49</th>
      <td>2023-11-19</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>50</th>
      <td>2023-11-20</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>51</th>
      <td>2023-11-21</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>52</th>
      <td>2023-11-22</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>53</th>
      <td>2023-11-23</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>54</th>
      <td>2023-11-24</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>55</th>
      <td>2023-11-25</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>56</th>
      <td>2023-11-26</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>57</th>
      <td>2023-11-27</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>58</th>
      <td>2023-11-28</td>
      <td>20.363636</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Merge the two dataframes on 'Date'

daily_data_merged = pd.merge(daily_totals, daily_average_price, on='Date')

```


```python
daily_data_merged 
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Total Sales</th>
      <th>Total Customers</th>
      <th>Price per Dish</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2023-10-01</td>
      <td>7680</td>
      <td>378</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2023-10-02</td>
      <td>8074</td>
      <td>399</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2023-10-03</td>
      <td>6922</td>
      <td>343</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2023-10-04</td>
      <td>8864</td>
      <td>422</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2023-10-05</td>
      <td>7388</td>
      <td>342</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>5</th>
      <td>2023-10-06</td>
      <td>9112</td>
      <td>443</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>6</th>
      <td>2023-10-07</td>
      <td>8158</td>
      <td>391</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>7</th>
      <td>2023-10-08</td>
      <td>8276</td>
      <td>397</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>8</th>
      <td>2023-10-09</td>
      <td>8458</td>
      <td>402</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>9</th>
      <td>2023-10-10</td>
      <td>8784</td>
      <td>414</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>10</th>
      <td>2023-10-11</td>
      <td>9678</td>
      <td>454</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>11</th>
      <td>2023-10-12</td>
      <td>7972</td>
      <td>385</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>12</th>
      <td>2023-10-13</td>
      <td>8930</td>
      <td>405</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>13</th>
      <td>2023-10-14</td>
      <td>8228</td>
      <td>394</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>14</th>
      <td>2023-10-15</td>
      <td>7124</td>
      <td>346</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>15</th>
      <td>2023-10-16</td>
      <td>6838</td>
      <td>330</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>16</th>
      <td>2023-10-17</td>
      <td>8110</td>
      <td>396</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>17</th>
      <td>2023-10-18</td>
      <td>8662</td>
      <td>400</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>18</th>
      <td>2023-10-19</td>
      <td>9468</td>
      <td>450</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>19</th>
      <td>2023-10-20</td>
      <td>7664</td>
      <td>380</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>20</th>
      <td>2023-10-21</td>
      <td>9258</td>
      <td>442</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>21</th>
      <td>2023-10-22</td>
      <td>8384</td>
      <td>414</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>22</th>
      <td>2023-10-23</td>
      <td>9516</td>
      <td>442</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>23</th>
      <td>2023-10-24</td>
      <td>9402</td>
      <td>441</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>24</th>
      <td>2023-10-25</td>
      <td>8340</td>
      <td>396</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>25</th>
      <td>2023-10-26</td>
      <td>8316</td>
      <td>408</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>26</th>
      <td>2023-10-27</td>
      <td>9058</td>
      <td>439</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>27</th>
      <td>2023-10-28</td>
      <td>7426</td>
      <td>373</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>28</th>
      <td>2023-10-29</td>
      <td>8834</td>
      <td>415</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>29</th>
      <td>2023-10-30</td>
      <td>9442</td>
      <td>439</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>30</th>
      <td>2023-10-31</td>
      <td>7948</td>
      <td>405</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>31</th>
      <td>2023-11-01</td>
      <td>8894</td>
      <td>425</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>32</th>
      <td>2023-11-02</td>
      <td>6624</td>
      <td>315</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>33</th>
      <td>2023-11-03</td>
      <td>8910</td>
      <td>425</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>34</th>
      <td>2023-11-04</td>
      <td>8626</td>
      <td>396</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>35</th>
      <td>2023-11-05</td>
      <td>7464</td>
      <td>370</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>36</th>
      <td>2023-11-06</td>
      <td>7166</td>
      <td>373</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>37</th>
      <td>2023-11-07</td>
      <td>8692</td>
      <td>408</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>38</th>
      <td>2023-11-08</td>
      <td>8404</td>
      <td>401</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>39</th>
      <td>2023-11-09</td>
      <td>7654</td>
      <td>370</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>40</th>
      <td>2023-11-10</td>
      <td>9300</td>
      <td>433</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>41</th>
      <td>2023-11-11</td>
      <td>8650</td>
      <td>412</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>42</th>
      <td>2023-11-12</td>
      <td>8232</td>
      <td>388</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>43</th>
      <td>2023-11-13</td>
      <td>7858</td>
      <td>398</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>44</th>
      <td>2023-11-14</td>
      <td>7936</td>
      <td>379</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>45</th>
      <td>2023-11-15</td>
      <td>7306</td>
      <td>349</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>46</th>
      <td>2023-11-16</td>
      <td>9670</td>
      <td>468</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>47</th>
      <td>2023-11-17</td>
      <td>7702</td>
      <td>371</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>48</th>
      <td>2023-11-18</td>
      <td>8742</td>
      <td>423</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>49</th>
      <td>2023-11-19</td>
      <td>7114</td>
      <td>351</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>50</th>
      <td>2023-11-20</td>
      <td>7746</td>
      <td>351</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>51</th>
      <td>2023-11-21</td>
      <td>9342</td>
      <td>449</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>52</th>
      <td>2023-11-22</td>
      <td>8276</td>
      <td>380</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>53</th>
      <td>2023-11-23</td>
      <td>8422</td>
      <td>403</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>54</th>
      <td>2023-11-24</td>
      <td>8572</td>
      <td>408</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>55</th>
      <td>2023-11-25</td>
      <td>6754</td>
      <td>316</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>56</th>
      <td>2023-11-26</td>
      <td>10436</td>
      <td>489</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>57</th>
      <td>2023-11-27</td>
      <td>8172</td>
      <td>386</td>
      <td>20.363636</td>
    </tr>
    <tr>
      <th>58</th>
      <td>2023-11-28</td>
      <td>8832</td>
      <td>424</td>
      <td>20.363636</td>
    </tr>
  </tbody>
</table>
</div>




```python

```


```python
plt.figure(figsize=(20, 10))
plt.bar(file['Date'], file['Total Sales'], color='lightblue')
plt.xlabel('Date')
plt.ylabel('Total Sales')
plt.title('Amount of Sales over time')
plt.xticks(rotation=45)
plt.tight_layout()
```


    
![png](output_33_0.png)
    



```python

```


```python
#plot and compare with seaborn
# Set seaborn style

sns.set(style="dark")
sns.histplot(data=file, x='Date', y=('Total Sales'), bins=10, kde=False, color='skyblue')

```




    <AxesSubplot:xlabel='Date', ylabel='Total Sales'>




    
![png](output_35_1.png)
    





```python
# Calculate the correlation matrix to see the relationship between total sales, total customers, and average price per dish

correlation_matrix = daily_data_merged[['Total Sales', 'Total Customers', 'Price per Dish']].corr()

```


```python
correlation_matrix
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Total Sales</th>
      <th>Total Customers</th>
      <th>Price per Dish</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Total Sales</th>
      <td>1.000000e+00</td>
      <td>9.646558e-01</td>
      <td>-3.739438e-17</td>
    </tr>
    <tr>
      <th>Total Customers</th>
      <td>9.646558e-01</td>
      <td>1.000000e+00</td>
      <td>7.947321e-17</td>
    </tr>
    <tr>
      <th>Price per Dish</th>
      <td>-3.739438e-17</td>
      <td>7.947321e-17</td>
      <td>1.000000e+00</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Plot the correlation matrix 
# And heatmap visualization of the correlation matrix
#The heatmap provides a color-coded representation of the correlation matrix
#making it easier to see the strength of the relationships between the variables.



plt.figure(figsize=(10, 8))
sns.heatmap(correlation_matrix, annot=True, fmt='.2f', cmap='coolwarm')
plt.title('Correlation Matrix of Daily Totals and Average Price')
plt.show()
```


    
![png](output_39_0.png)
    



```python

```


```python
# Now let us do Linear Regression Analysis to test our model

from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
```


```python
# Prepare the features and target variable for linear regression
X = daily_data_merged[['Total Customers', 'Price per Dish']]
y = daily_data_merged['Total Sales']

```


```python
# Split the data into training and testing sets

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

```


```python
# Initialize the Linear Regression model

model = LinearRegression()

```


```python
# Fit the model on the training data

model.fit(X_train, y_train)
```




    LinearRegression()




```python
# Predict on the testing data

y_pred = model.predict(X_test)
```


```python
# Calculate the mean squared error and the R-squared value

mse = mean_squared_error(y_test, y_pred)
r_squared = r2_score(y_test, y_pred)
```


```python
# Display the model performance metrics

print('Mean Squared Error:', mse)
print('R-squared:', r_squared)

```

    Mean Squared Error: 42879.01232709874
    R-squared: 0.8868609731892887
    


```python
#Conclusion
# These metrics indicate that the model has a relatively low error 
# and a high proportion of the variance in the total sales is predictable 
# from the number of customers and the average price per dish.


```
